package emoa.nsgaii;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.Algorithm;
import core.Operator;
import core.Problem;
import core.Solution;
import utils.PseudoRandomGenerator;
import utils.calculation.CrowdingDistanceAssignment;
import utils.comparator.CrowdingDistanceComparator;
import utils.comparator.ParetoComparator;
import utils.ranking.NondominatedSort;
import utils.ranking.Ranking;

public class NSGAII_base_jmetal extends Algorithm{

	int numberOfIterations_;
	int numberOfGenerations_;

	int populationSize_;

	ArrayList<Solution> solutionSet_;

	ArrayList<Solution> offspringSet_;

	ArrayList<Solution> mergeSet_;

	Operator crossover_;
	Operator mutation_;
	Operator selection_;
	boolean minimize_;



	public NSGAII_base_jmetal(Problem problem) {
		super(problem);
	}


	@Override
	public ArrayList<Solution> execute() throws ClassNotFoundException {

		populationSize_ = (Integer)this.getInputParameter("populationSize");

		numberOfIterations_ = (Integer)this.getInputParameter("numberOfIterations");
		numberOfGenerations_ = (Integer)this.getInputParameter("numberOfGenerations");

		crossover_ = this.getOperator("crossover");
		mutation_ = this.getOperator("mutation");
		selection_ = this.getOperator("selection");
		minimize_ = (Boolean)this.getInputParameter("minimize");
		ParetoComparator.setOptimize("max");
		if(minimize_) ParetoComparator.setOptimize("min");


		int generation = 0;

		solutionSet_ = new ArrayList<Solution>();

		initialize();

		int t = solutionSet_.size();
		System.out.println("t: " + t);

		while(t < this.numberOfIterations_ && generation < this.numberOfGenerations_) {

			offspringSet_ = new ArrayList<Solution>();
			for(int i = 0; i < populationSize_ ; i++) {
				if(t < this.numberOfIterations_ && offspringSet_.size() < populationSize_) {

					ArrayList<Solution> parents = new ArrayList<Solution>();
					ArrayList<Solution> children;

					parents.add((Solution)selection_.execute(solutionSet_));
					parents.add((Solution)selection_.execute(solutionSet_));

					children = (ArrayList<Solution>)crossover_.execute(parents);

					Solution s = (Solution)mutation_.execute(children.get(PseudoRandomGenerator.randInt(0, 2)));
					problem_.evaluate(s);
					problem_.evaluateConstraintViolation(s);
					offspringSet_.add(s);
					t++;
					//System.out.println("t: " + t);
					if(t >= this.numberOfIterations_) break;

				}//if
			}//for

			mergeSet_ = new ArrayList<Solution>();

			mergeSolutionSet(solutionSet_, offspringSet_);

			Random rnd = new Random(PseudoRandomGenerator.randInt());

			Collections.shuffle(mergeSet_, rnd);

			int sizeOfMergeSet_ = mergeSet_.size();

			ArrayList<Integer> individualNumber = new ArrayList<>();
			for(int i = 0; i < sizeOfMergeSet_; i++) {
				individualNumber.add(i);
			}
			Collections.shuffle(individualNumber, rnd);
			assert(individualNumber.size()==sizeOfMergeSet_);
			for(int i = 0; i < sizeOfMergeSet_; i++) {
				mergeSet_.get(i).setIndividualNumber(individualNumber.get(i));
			}

			Ranking ranking = new NondominatedSort(mergeSet_);

			int remain = populationSize_;
			int index = 0;
			ArrayList<Solution> front = null;
			solutionSet_ = new ArrayList<Solution>();

			front = ranking.getSubFront(index);

			while ((remain > 0) && (remain >= front.size())) {

				new CrowdingDistanceAssignment().assign(front, problem_.getNumberOfObjectives());

				solutionSet_.addAll(front);
				// Decrement remain
				remain = remain - front.size();
				// Obtain the next front
				index++;
				if (remain > 0) {
					front = ranking.getSubFront(index);
				} // if
			}

			ArrayList<Solution> lastFront = new ArrayList<>();
			if(remain > 0) {
				new CrowdingDistanceAssignment().assign(front, problem_.getNumberOfObjectives());
				Collections.sort(front, new CrowdingDistanceComparator());

				int cn = 0;
				while(remain > 0){
					lastFront.add(front.get(cn));
					cn++;
					remain--;
				}
			}

			solutionSet_.addAll(lastFront);

			assert(solutionSet_.size() == populationSize_);

			new CrowdingDistanceAssignment().assign(lastFront, problem_.getNumberOfObjectives());

			generation++;
			System.out.println("t: " + t);

			Collections.shuffle(solutionSet_, rnd);
			System.out.println("generation: " + generation);

		}//while

		Ranking ranking = new NondominatedSort(solutionSet_);

		return ranking.getSubFront(0);
	}


	void initialize() throws ClassNotFoundException {
		for(int i = 0; i < populationSize_; i++) {
			Solution s = new Solution(problem_);
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
			solutionSet_.add(s);
		}
	}


	void mergeSolutionSet(ArrayList<Solution> set1, ArrayList<Solution> set2) {
		this.mergeSet_.addAll(set1);
		this.mergeSet_.addAll(set2);
	}


	@Override
	public void setting() {
		// TODO 自動生成されたメソッド・スタブ
	}

}
