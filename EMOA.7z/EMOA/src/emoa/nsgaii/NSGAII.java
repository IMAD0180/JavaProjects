package emoa.nsgaii;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.Operator;
import core.Problem;
import core.Solution;
import emoa.ga.GeneticAlgorithm;
import utils.PseudoRandomGenerator;
import utils.calculation.CrowdingDistanceAssignment;
import utils.comparator.BinaryTournamentComparator;
import utils.comparator.ParetoComparator;
import utils.ranking.NondominatedSort;
import utils.ranking.Ranking;

public class NSGAII extends GeneticAlgorithm{

	public NSGAII(Problem problem) {
		super(problem);
	}

	int numberOfObjectives_;

	int numberOfIterations_;

	int iteration_;

	int sizeOfPopulation_;

	Operator crossover_;

	Operator mutation_;

	Operator selection_;

	boolean minimize_;

	boolean archivemode_;

	@Override
	public void setting() {
		this.sizeOfPopulation_ = (Integer)this.getInputParameter("sizeOfPopulation");
		this.numberOfIterations_ = (Integer)this.getInputParameter("numberOfIterations");
		crossover_ = this.getOperator("crossover");
		mutation_ = this.getOperator("mutation");
		selection_ = this.getOperator("selection");
		minimize_ = (Boolean)this.getInputParameter("minimize");
		ParetoComparator.setOptimize("max");
		if(minimize_) ParetoComparator.setOptimize("min");
		this.numberOfObjectives_ = this.problem_.getNumberOfObjectives();
	}

	@Override
	public void initialize() throws ClassNotFoundException {
		for(int i = 0; i < sizeOfPopulation_; i++) {
			if(i > numberOfIterations_) break;
			Solution s = new Solution(problem_);
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
			population_.add(s);
		}
	}

	@Override
	public void recombination()  throws ClassNotFoundException{
		while(!isTerminated(iteration_) && children_.size() < sizeOfPopulation_) {
		ArrayList<Solution> parents = new ArrayList<Solution>();
		ArrayList<Solution> children;
		parents.add((Solution)selection_.execute(population_));
		parents.add((Solution)selection_.execute(population_));
		children = (ArrayList<Solution>)crossover_.execute(parents);
		Solution s = (Solution)mutation_.execute(children.get(PseudoRandomGenerator.randInt(0, 2)));
		problem_.evaluate(s);
		problem_.evaluateConstraintViolation(s);
		children_.add(s);
		iteration_++;
		}
	}

	@Override
	public void updatePopulation()  throws ClassNotFoundException{
		Random rnd = new Random(PseudoRandomGenerator.randInt());
		Collections.shuffle(nextPopulation_, rnd);
		int sizeOfnextPopulation_ = nextPopulation_.size();
		for(int i = 0; i < sizeOfnextPopulation_; i++) nextPopulation_.get(i).setIndividualNumber(i);

		Ranking ranking = new NondominatedSort(nextPopulation_);
		for(int i = 0, size = ranking.getNumberOfSubFronts(); i < size; i++) {
			new CrowdingDistanceAssignment().assign(ranking.getSubFront(i), problem_.getNumberOfObjectives());
		}
		Collections.sort(nextPopulation_, new BinaryTournamentComparator());
		population_.clear();
		int cn = 0;
		while(population_.size() < sizeOfPopulation_) {
			population_.add(nextPopulation_.get(cn));
			cn++;
		}
		ranking = new NondominatedSort(population_);
		for(int i = 0, size = ranking.getNumberOfSubFronts(); i < size; i++) {
			new CrowdingDistanceAssignment().assign(ranking.getSubFront(i), problem_.getNumberOfObjectives());
		}
		Collections.shuffle(population_, rnd);
	}

	@Override
	public boolean isTerminated(int t) {
		return (t >= numberOfIterations_);
	}

	@Override
	public ArrayList<Solution> execute() throws ClassNotFoundException {
		population_ = new ArrayList<Solution>();
		children_ = new ArrayList<Solution>();
		nextPopulation_ = new ArrayList<Solution>();
		initialize();
		iteration_ = population_.size();
		//iteration_ = 0;
		while(!isTerminated(iteration_)) {
			children_.clear();
			recombination();
			nextPopulation_.clear();
			nextPopulation_.addAll(population_);
			nextPopulation_.addAll(children_);
			updatePopulation();
		}
		Ranking ranking = new NondominatedSort(population_);
		return ranking.getSubFront(0);
	}
}
