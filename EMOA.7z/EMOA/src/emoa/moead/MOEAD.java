package emoa.moead;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import core.Operator;
import core.Portion;
import core.Problem;
import core.Solution;
import emoa.ga.GeneticAlgorithm;
import utils.PseudoRandomGenerator;
import utils.calculation.MathCalculation;
import utils.calculation.ScalarizingFunction;
import utils.comparator.AscendingOrderComparator;
import utils.comparator.ParetoComparator;
import utils.vector.TwoLevelWeightVectorGenerator;
import utils.vector.VectorGenerator;

public class MOEAD extends GeneticAlgorithm {

	int numberOfObjectives_;

	int numberOfIterations_;

	int iteration_;

	int sizeOfPopulation_;

	int sizeOfNeighborhood_;

	int H1_;

	int H2_;

	boolean inverse_;

	ArrayList<ArrayList<Double>> lambda_;

	double[] zIdeal_;

	double[] zNadir_;

	int[][] neighbor_;

	Operator crossover_;

	Operator mutation_;

	Operator selection_;

	boolean minimize_;

	boolean archivemode_;

	int id_;

	String functionName_;

	ScalarizingFunction sf_;

	double theta_;

	public MOEAD(Problem problem) {
		super(problem);
	}

	@Override
	public void setting() {
		this.H1_ = (Integer)this.getInputParameter("H1");
		this.H2_ = (Integer)this.getInputParameter("H2");
		this.numberOfIterations_ = (Integer)this.getInputParameter("numberOfIterations");
		this.sizeOfNeighborhood_ = (Integer)this.getInputParameter("sizeOfNeighborhood");
		this.inverse_ = (Boolean)this.getInputParameter("inverse");
		this.functionName_ = (String)this.getInputParameter("scalarizingFunction");
		sf_ = new ScalarizingFunction(functionName_);
		if(this.getInputParameter("theta") != null)
			this.theta_ = (Double)this.getInputParameter("theta");
		crossover_ = this.getOperator("crossover");
		mutation_ = this.getOperator("mutation");
		selection_ = this.getOperator("selection");
		minimize_ = (Boolean)this.getInputParameter("minimize");
		ParetoComparator.setOptimize("max");
		if(minimize_) ParetoComparator.setOptimize("min");
		this.numberOfObjectives_ = this.problem_.getNumberOfObjectives();
	}

	@Override
	public void initialize() throws ClassNotFoundException {

		VectorGenerator vg = new TwoLevelWeightVectorGenerator(H1_, H2_, numberOfObjectives_, inverse_);
		this.lambda_ = vg.getVectors();
		Random rnd = new Random(PseudoRandomGenerator.randInt());
		Collections.shuffle(lambda_, rnd);

		this.sizeOfPopulation_ = this.lambda_.size();
//		if(this.getInputParameter("sizeOfPopulation") != null)
//			sizeOfPopulation_ = (Integer)this.getInputParameter("sizeOfPopulation");
		zIdeal_ = new double[problem_.getNumberOfObjectives()];
		zNadir_ = new double[problem_.getNumberOfObjectives()];
		for(int i = 0; i < numberOfObjectives_; i++) {
			if(minimize_) {
				zIdeal_[i] = Double.MAX_VALUE;
			} else {
				zIdeal_[i] = -Double.MAX_VALUE;
			}
		}
		for(int i = 0; i < sizeOfPopulation_; i++) {
			if(i > numberOfIterations_) break;
			Solution s = new Solution(problem_);
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
			population_.add(s);
			iteration_++;
			updateZ(s);
		}

		sizeOfNeighborhood_ = (int) (sizeOfPopulation_ * 0.1);   // Lab. setting
		neighbor_ = new int[lambda_.size()][sizeOfNeighborhood_];
		neighbor_ = initializeNeighbor(neighbor_, lambda_);
	}

	@Override
	public void recombination() throws ClassNotFoundException {
		ArrayList<Solution> parents = new ArrayList<Solution>();
		ArrayList<Solution> children;
		Solution s;
		while(parents.size() < 2) {
			int length = neighbor_[id_].length;
			int index = neighbor_[id_][PseudoRandomGenerator.randInt(0, length)];
			s = new Solution(population_.get(index));
			parents.add(s);
		}
		children = (ArrayList<Solution>)crossover_.execute(parents);
		s = (Solution)mutation_.execute(children.get(PseudoRandomGenerator.randInt(0, 2)));
		problem_.evaluate(s);
		problem_.evaluateConstraintViolation(s);
		children_.add(s);
		iteration_++;
	}

	@Override
	public void updatePopulation() throws ClassNotFoundException {
		for(int i = 0; i < sizeOfNeighborhood_; i++) {
			int id = neighbor_[id_][i];
			double childF = sf_.calculate(children_.get(0), lambda_.get(id), zIdeal_, zNadir_, theta_);
			double parentF = sf_.calculate(population_.get(id), lambda_.get(id), zIdeal_, zNadir_, theta_);
			if(minimize_ && childF <= parentF) {
				population_.remove(id);
				population_.add(id, children_.get(0));
			} else if(!minimize_ && parentF <= childF) {
				population_.remove(id);
				population_.add(id, children_.get(0));
			}
		}
	}

	@Override
	public boolean isTerminated(int t) {
		return (t >= numberOfIterations_);
	}

	@Override
	public ArrayList<Solution> execute() throws ClassNotFoundException {
		iteration_ = 0;
		population_ = new ArrayList<Solution>();
		children_ = new ArrayList<Solution>();
		nextPopulation_ = new ArrayList<Solution>();
		initialize();
		while(!isTerminated(iteration_)) {
			for(int id = 0; id < sizeOfPopulation_; id++) {
				if(isTerminated(iteration_)) break;
				id_ = id;
				children_.clear();
				recombination();
				updateZ(children_.get(0));
				nextPopulation_.clear();
				nextPopulation_.addAll(population_);
				nextPopulation_.addAll(children_);
				calculateNadir();
				updatePopulation();
			}
		}
//		Ranking ranking = new NondominatedSort(population_);
//		return ranking.getSubFront(0);
		return population_;
	}

	public int[][] initializeNeighbor(int[][] neighbor, ArrayList<ArrayList<Double>> lambda) {
		assert neighbor.length == lambda.size() : "neghbor's length is different from lambda's size!";
		double distance;
		for(int i = 0, size = lambda.size(); i < size; i++) {
			ArrayList<Portion> portionArray = new ArrayList<>();
			for(int j = 0; j < size; j++) {
				if(i == j) {
					Portion portion = new Portion(j, 0.0);
					portionArray.add(portion);
					continue;
				}
				distance = MathCalculation.calculateEuclideanDistance(lambda.get(i), lambda.get(j));
				Portion portion = new Portion(j, distance);
				portionArray.add(portion);
			}
			Random rnd = new Random(PseudoRandomGenerator.randInt());
			Collections.shuffle(portionArray, rnd);
			Collections.sort(portionArray, new AscendingOrderComparator());
			for(int j = 0; j < sizeOfNeighborhood_; j++)
				neighbor[i][j] = portionArray.get(j).getId();
		}
		return neighbor;
	}

	void updateZ(Solution s) {
		for(int i = 0, m = problem_.getNumberOfObjectives(); i < m; i++) {
			if(minimize_) {
				if(zIdeal_[i] > s.getObjective(i)) zIdeal_[i] = s.getObjective(i);
			} else {
				if(zIdeal_[i] < s.getObjective(i)) zIdeal_[i] = s.getObjective(i);
			}
		}
	}

	void calculateNadir() {
		double nadir;
		for(int i = 0; i < numberOfObjectives_; i++) {
			assert nextPopulation_.size() > 0 : "No individual!";
			nadir = nextPopulation_.get(0).getObjective(i);
			for(int pop = 0; pop < nextPopulation_.size(); pop++) {
				double value = nextPopulation_.get(pop).getObjective(i);
				if(minimize_ && nadir < value) {
					nadir = value;
				} else if(!minimize_ && nadir > value){
					nadir = value;
				}
			}
			zNadir_[i] = nadir;
		}
	}

}
