package emoa.smsemoa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import core.Algorithm;
import core.Operator;
import core.Problem;
import core.Solution;
import utils.PseudoRandomGenerator;
import utils.comparator.ObjectiveComparator;
import utils.comparator.ParetoComparator;
import utils.indicator.IHSO;
import utils.indicator.InvertedGenerationalDistance;
import utils.ranking.NondominatedSort;
import utils.ranking.Ranking;

public class SMSEMOA_Nadir extends Algorithm{

	int numberOfIterations_;

	int populationSize_;

	ArrayList<Solution> solutionSet_;

	ArrayList<Solution> offspringSet_;

	ArrayList<Solution> mergeSet_;

	Operator crossover_;
	Operator mutation_;
	Operator selection_;

	boolean minimize_;

	double[] referencePoint;
	double ri_;

	ArrayList<ArrayList<Double>> lambda;

	String fileName_;

	double[][] estimatedValues_;

	int numberOfRuns_;

	public SMSEMOA_Nadir(Problem problem) {
		super(problem);
	}

	@Override
	public ArrayList<Solution> execute() throws ClassNotFoundException {

		populationSize_ = (Integer)this.getInputParameter("populationSize");

		numberOfIterations_ = (Integer)this.getInputParameter("numberOfIterations");

		crossover_ = this.getOperator("crossover");
		mutation_ = this.getOperator("mutation");
		selection_ = this.getOperator("selection");

		minimize_ = (Boolean)this.getInputParameter("minimize");
		ParetoComparator.setOptimize("max");
		if(minimize_) ParetoComparator.setOptimize("min");

		ri_ = (Double)this.getInputParameter("HVreference");
		numberOfRuns_ = (int)this.getInputParameter("numberOfRuns");

		estimatedValues_ = new double[numberOfIterations_+1][2];

		initLambda(ri_);

		int t = 0;
		int from = 1;
		int to;

		solutionSet_ = new ArrayList<Solution>();

		initialize();

		while(t < this.numberOfIterations_) {

			offspringSet_ = new ArrayList<Solution>();

			ArrayList<Solution> parents = new ArrayList<Solution>();
			ArrayList<Solution> children;

			parents.add((Solution)selection_.execute(solutionSet_));
			parents.add((Solution)selection_.execute(solutionSet_));

			children = (ArrayList<Solution>)crossover_.execute(parents);

			Solution s = (Solution)mutation_.execute(children.get(PseudoRandomGenerator.randInt(0, 2)));
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
			offspringSet_.add(s);

			mergeSet_ = new ArrayList<Solution>();

			mergeSolutionSet(solutionSet_, offspringSet_);

			Ranking ranking = new NondominatedSort(mergeSet_);

			int remain = populationSize_;
			int index = 0;
			ArrayList<Solution> front = null;
			solutionSet_ = new ArrayList<Solution>();

			front = ranking.getSubFront(index);

			this.referencePoint = calculateNadir(front);

			while ((remain > 0) && (remain >= front.size())) {

				for (int k = 0, size = front.size(); k < size; k++) {
					solutionSet_.add(front.get(k));
				} // for
				// Decrement remain
				remain = remain - front.size();
				// Obtain the next front
				index++;
				if (remain > 0) {
					front = ranking.getSubFront(index);
				} // if
			}

			ArrayList<Solution> sols = new ArrayList<>();
			if(remain > 0) {
				sols = EnvironmentalSelection(front);
				solutionSet_.clear();
				solutionSet_.addAll(sols);
				remain = 0;
			}
			t++;
			objectiveRecalculation(solutionSet_);
			System.out.println("t: " + t);
//			calculateIGD(solutionSet_, t);

			if(t%1000 == 0) {
				to = t;
//				PrintIGD(from, to);
//				PrintSolutionSet(to);
				from = to + 1;
			}

		}//while

//		PrintIGD(1,numberOfIterations_);

		return solutionSet_;
	}


	void initialize() throws ClassNotFoundException {
		for(int i = 0; i < populationSize_; i++) {
			Solution s = new Solution(problem_);
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
			solutionSet_.add(s);
		}
	}


	void initLambda(double ri) {
		this.referencePoint = new double[this.problem_.getNumberOfObjectives()];
		for(int i = 0, size = referencePoint.length; i < size; i++) {
			referencePoint[i] = ri;
		}
	}


	void initLambda(String fileName) {
		this.lambda = new ArrayList<>();
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			while((temp = br.readLine()) != null){
				String[] array = temp.split(",");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				lambda.add(refPoint);
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			System.err.println(e);
		}
	}


	void calculateHVContribution(ArrayList<Solution> solutionSet, int t) {
		assert(t>=0);
		InvertedGenerationalDistance igd = new InvertedGenerationalDistance(lambda, solutionSet);
		estimatedValues_[t-1][0] = t;
		estimatedValues_[t-1][1] = igd.CalculateIGD();
	}


	void PrintIGD(int from, int to) {
		try {
			File file = new File("HVContribution_r" + numberOfRuns_ + "_m" + problem_.getNumberOfObjectives()
								  + "_f" + from + "_t" + to + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = from-1; i < to; i++) {
				pw.println(estimatedValues_[i][0] + " " + estimatedValues_[i][1]);
			}
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	void PrintIGD() {
		try {
			File file = new File("HVContribution_r" + numberOfRuns_ + "_m" + problem_.getNumberOfObjectives()
								  + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			pw.println(estimatedValues_[this.numberOfIterations_][0] + " " + estimatedValues_[this.numberOfIterations_][1]);
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	void PrintSolutionSet(int to) {
		try {
			File file = new File("FUN_r" + numberOfRuns_ + "_m" + problem_.getNumberOfObjectives() +
								 "_t" + to + ".csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = 0; i < solutionSet_.size(); i++) {
				for(int j = 0; j < solutionSet_.get(i).getObjectives().length; j++) {
					//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
					pw.print(solutionSet_.get(i).getObjective(j));
					if(j < solutionSet_.get(i).getObjectives().length - 1)
						pw.print(" ");
				}
				pw.println();
			}
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	double[] calculateNadir(ArrayList<Solution> firstFront) {
		double[] refs = new double[problem_.getNumberOfObjectives()];
		for(int i = 0, m = problem_.getNumberOfObjectives(); i < m; i++) {
			double ri = 0.0;
			if(minimize_) {
				double max = -Double.MAX_VALUE;
				for(Solution s: firstFront) {
					if(max < s.getObjective(i)) max = s.getObjective(i);
				}
				ri = max;
			} else {
				double min = Double.MAX_VALUE;
				for(Solution s: firstFront) {
					if(min > s.getObjective(i)) min = s.getObjective(i);
				}
				ri = min;
			}
			refs[i] = ri + 1;
		}
		return refs;
	}


	void mergeSolutionSet(ArrayList<Solution> set1, ArrayList<Solution> set2) {
		this.mergeSet_.addAll(set1);
		this.mergeSet_.addAll(set2);
	}


	ArrayList<Solution> convertToMinus(double[] r, ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		assert(r.length == solutionSet.get(0).getObjectives().length);
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			sols.add(new Solution(solutionSet.get(i)));
			for(int j = 0; j < r.length; j++) {
				double value = -1.0 * sols.get(i).getObjective(j);
				sols.get(i).setObjective(j, value);
			}
		}
		for(int i = 0; i < r.length; i++) {
			r[i] *= -1.0;
		}
		return sols;
	}


	ArrayList<Solution> convertToMinus(ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			sols.add(new Solution(solutionSet.get(i)));
			for(int j = 0; j < solutionSet.get(0).getObjectives().length; j++) {
				double value = -1.0 * sols.get(i).getObjective(j);
				sols.get(i).setObjective(j, value);
			}
		}
		return sols;
	}


	static boolean strongDominate(double[] r, Solution sol) {
		boolean dominate = true;
		for(int m = 0, numberOfObjectives = r.length; m < numberOfObjectives; m++) {
			if(sol.getObjective(m) <= r[m]) {
				dominate = false;
				break;
			}
		}
		return dominate;
	}


	static boolean duplicate(Solution sol1, Solution sol2) {
		boolean duplicated = true;
		assert(sol1.getObjectives().length == sol2.getObjectives().length);
		for(int m = 0, numberOfObjectives = sol1.getObjectives().length; m < numberOfObjectives; m++) {
			if(sol1.getObjective(m) != sol2.getObjective(m)) {
				duplicated = false;
				break;
			}
		}
		return duplicated;
	}


	ArrayList<Solution> objectiveNormalization(ArrayList<Solution> solutionSet) {
		ArrayList<Solution> pop = new ArrayList<>();
		for(Solution s : solutionSet) {
			pop.add(new Solution(s));
		}
		Ranking ranking = new NondominatedSort(pop);
		assert(ranking.getNumberOfSubFronts()>0);
		ArrayList<Solution> topFront = ranking.getSubFront(0);
		for(int i = 0, m = problem_.getNumberOfObjectives(); i < m; i++) {
			Collections.sort(topFront, new ObjectiveComparator(i));
			double minObjective = topFront.get(0).getObjective(i);
			double maxObjective = topFront.get(topFront.size()-1).getObjective(i);
			double denominator = Math.abs(maxObjective - minObjective);
			if(denominator < 1.0e-10)
				denominator = 1.0e-10;
			for(int j = 0, size = pop.size(); j < size; j++) {
				double numerator = pop.get(j).getObjective(i) - minObjective;
				pop.get(j).setObjective(i, numerator / denominator);
			}
		}
		Random rnd = new Random(PseudoRandomGenerator.randInt(0, numberOfRuns_*1000));
		Collections.shuffle(pop, rnd);
		return pop;
	}


	void objectiveRecalculation(ArrayList<Solution> pop) throws ClassNotFoundException {
		for(Solution s : pop) {
			problem_.evaluate(s);
			problem_.evaluateConstraintViolation(s);
		}
	}


//	ArrayList<Solution> EnvironmentalSelection(ArrayList<Solution> solutionSet) {
//		assert(solutionSet.size()>0);
//		int rank = solutionSet.get(0).getRank();
//		int index = -1;
//		double minContribution = Double.MAX_VALUE;
//		ArrayList<Solution> mergeSet = new ArrayList<>();
//		ArrayList<Integer> originalIndexArray = new ArrayList<>();
//		int cn = 0;
//		for(int i = 0, size = solutionSet_.size(); i < size; i++) {
//			mergeSet.add(new Solution(solutionSet_.get(i)));
//			mergeSet.get(i).setIndividualNumber(cn);
//			originalIndexArray.add(cn);
//			cn++;
//		}
//		for(int i = 0, size = solutionSet.size(); i < size; i++) {
//			mergeSet.add(new Solution(solutionSet.get(i)));
//			mergeSet.get(i).setIndividualNumber(cn);
//			originalIndexArray.add(cn);
//			cn++;
//		}
//
//		if(minimize_) {
//			mergeSet = convertToMinus(referencePoint, mergeSet);
//		}
//
//		ArrayList<Integer> indArray = new ArrayList<>();
//		for(int i = 0; i < referencePoint.length; i++) {
//			indArray.add(i);
//		}
//		Random rnd = new Random(PseudoRandomGenerator.randInt(0, 1000*numberOfRuns_));
//		Collections.shuffle(indArray);
//
//		for(int i = 0; i < referencePoint.length; i++) {
//			Collections.sort(mergeSet,  new ObjectiveComparator(indArray.get(i), false));
//		}
//
//		long start = System.currentTimeMillis();
//
//		ArrayList<Integer> minContributionIndex = new ArrayList<>();
//
//		for(int i = 0, size = mergeSet.size(); i < size; i++) {
//			if(mergeSet.get(i).getRank() != rank) continue;
//			//System.out.println("iteration of calculations of contribution solution: " + i);
//			double contribution = 0.0;
//
//			if(!strongDominate(referencePoint, mergeSet.get(i))) {
//				if(contribution <= minContribution) {
//					minContributionIndex.add(i);
//					minContribution = contribution;
//				}
//				continue;
//			}
//
//			if((i < solutionSet.size()-1) && (duplicate(mergeSet.get(i), mergeSet.get(i+1)))) {
//				if(contribution <= minContribution) {
//					minContributionIndex.add(i);
//					minContribution = contribution;
//				}
//				continue;
//			}
//
//			ArrayList<Solution> sols = new ArrayList<>();
//			Solution z = new Solution(mergeSet.get(i));
//			for(int j = 0; j < size; j++) {
//				if(j == i) continue;
//				sols.add(mergeSet.get(j));
//			}
//			IHSO ihso = new IHSO(sols, referencePoint, z);
//			contribution = ihso.execute();
//			//System.out.println("");
//			if(contribution <= minContribution) {
//				minContributionIndex.add(i);
//				minContribution = contribution;
//			}
//		}
//
//		if(minimize_) {
//			mergeSet = convertToMinus(referencePoint, mergeSet);
//		}
//
//		long finish = System.currentTimeMillis();
//		System.out.println("time: " + (finish - start));
//
//		if(minContributionIndex.size()>0)
//			index = minContributionIndex.get(PseudoRandomGenerator.randInt(0, minContributionIndex.size()));
//
//		//index = PseudoRandomGenerator.randInt(0, mergeSet.size());
//
//		ArrayList<Solution> sols = new ArrayList<>();
//		for(int i = 0, size = mergeSet.size(); i < size; i++) {
//			if(i == index) continue;
//			sols.add(mergeSet.get(i));
//		}
//
//		return sols;
//	}


	ArrayList<Solution> EnvironmentalSelection(ArrayList<Solution> solutionSet) {
		ArrayList<Solution> sols = new ArrayList<>();
		long start = System.currentTimeMillis();
		for(Solution s: this.solutionSet_) sols.add(new Solution(s));
		if(solutionSet.size() == 1) return sols;

		for(Solution s: solutionSet) sols.add(new Solution(s));

		if(minimize_) sols = convertToMinus(referencePoint, sols);

		ArrayList<Integer> not_dominate = new ArrayList<>();
		for(int i = 0, size = sols.size(); i < size; i++) {
			if(!strongDominate(referencePoint, sols.get(i))) not_dominate.add(i);
		}
		if(not_dominate.size() > 0) {
			int index = PseudoRandomGenerator.randInt(0, not_dominate.size());
			sols.remove((int)not_dominate.get(index));
			if(minimize_) sols = convertToMinus(referencePoint, sols);
			return sols;
		}

		Set<Integer> dup_sols = new HashSet<>();
		for(int i = 0, size = sols.size(); i < size; i++) {
			for(int j = i + 1; j < size; j++) {
				if(duplicate(sols.get(i), sols.get(j))) {
					dup_sols.add(i);
					dup_sols.add(j);
				}
			}
		}
		if(dup_sols.size() > 0) {
			int index = PseudoRandomGenerator.randInt(0, dup_sols.size());
			int count = 0;
			for(int ind: dup_sols) {
				if(count == index) {
					sols.remove((int)ind);
					if(minimize_) sols = convertToMinus(referencePoint, sols);
					return sols;
				} else {
					count++;
				}
			}
		}

		ArrayList<Solution> n_sols = new ArrayList<>();
		for(int i = 0, size = sols.size(); i < size; i++) {
			n_sols.add(new Solution(sols.get(i)));
			n_sols.get(i).setIndividualNumber(i);
		}

		Collections.sort(n_sols, new ObjectiveComparator(0, false));
		int index = 0;
		double min = Double.MAX_VALUE;
		ArrayList<Integer> indexArray = new ArrayList<>();
		for(int i = 0, size = n_sols.size(); i < size; i++) {
			ArrayList<Solution> temp_sols = new ArrayList<>();
			Solution z = new Solution(n_sols.get(i));
			for(int j = 0; j < size; j++) {
				if(i == j) continue;
				temp_sols.add(n_sols.get(j));
			}
			IHSO ihso = new IHSO(temp_sols, referencePoint, z);
			double contribution = ihso.execute();
			if(contribution < min) {
				min = contribution;
				index = i;
				indexArray.clear();
				indexArray.add(i);
			} else if(contribution == min){
				indexArray.add(i);
			}
		}
		index = indexArray.get(PseudoRandomGenerator.randInt(0, indexArray.size()));
		sols.remove(n_sols.get(index).getIndividualNumber());
		long finish = System.currentTimeMillis();

		System.out.println("time: " + (finish - start));
		if(minimize_) sols = convertToMinus(referencePoint, sols);

		return sols;
	}

	@Override
	public void setting() {
		// TODO 自動生成されたメソッド・スタブ

	}

}
