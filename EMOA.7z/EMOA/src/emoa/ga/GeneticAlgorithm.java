package emoa.ga;

import java.util.ArrayList;

import core.Algorithm;
import core.Problem;
import core.Solution;

public abstract class GeneticAlgorithm extends Algorithm{

	public GeneticAlgorithm(Problem problem) {
		super(problem);
	}

	protected ArrayList<Solution> population_;
	protected ArrayList<Solution> children_;
	protected ArrayList<Solution> nextPopulation_;
	protected ArrayList<Solution> archive_;

	abstract public void setting();

	abstract public void initialize() throws ClassNotFoundException;

	abstract public void recombination() throws ClassNotFoundException;

	abstract public void updatePopulation() throws ClassNotFoundException;

	abstract public boolean isTerminated(int t);

}
