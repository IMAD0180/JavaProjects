package operator.mutation;

import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class PolynomialMutation extends Operator {

	double mutationProbability_ = 0.1;
	double distributionIndex_ = 20.0;


	//Constructor
	public PolynomialMutation(HashMap<String, Object> parameters) {
		super(parameters);

		if (parameters.get("probability") != null)
			mutationProbability_ = (Double) parameters.get("probability");
		if (parameters.get("distributionIndex") != null)
			distributionIndex_    = (Double) parameters.get("distributionIndex");
	}


	@Override
	public Object execute(Object object) {

		//System.out.println(mutationProbability_);
		//System.out.println(distributionIndex_);

		Solution s = (Solution) object;
		if(s.getSolutionType() != "Real") {
			System.err.println("Solution type is Real!!!");
			System.exit(-1);
		}

		Solution q = new Solution(s);

		double qi;
		double eta = this.distributionIndex_ + 1.0;

		for(int i = 0, length = q.getVariables().length; i < length; i++) {
			double lb = q.getLowerbound(i);
			double ub = q.getUpperbound(i);
			double si = q.getVariable(i);
			double var;
			if(PseudoRandomGenerator.randDouble() < this.mutationProbability_) {


				double delta1 = (si - lb) / (ub - lb);
				double delta2 = (ub - si) / (ub - lb);
				double delta_q;
				double r = PseudoRandomGenerator.randDouble();

				if(r < 0.5) {
					var = 2.0 * r + (1.0 - 2.0 * r) * (Math.pow((1.0 - delta1), eta));
					delta_q = Math.pow(var, 1.0 / eta) - 1.0;
				} else {
					var = 2.0 * (1.0 - r) + 2.0 * (r - 0.5) * (Math.pow((1.0 - delta2), eta));
					delta_q = 1.0 - Math.pow(var, 1.0 / eta);
				}
				qi = si + delta_q * (ub - lb);
			} else {
				qi = q.getVariable(i);
			}

			if (qi<lb)
				qi = lb;
			if (qi>ub)
				qi = ub;

			q.setVariable(i, qi);
		}

		return q;
	}

}
