package operator.mutation;

import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class BitFlipMutation extends Operator {

	double mutationProbability_ = 0.002;

	public BitFlipMutation(HashMap<String, Object> parameters) {
		super(parameters);

		if (parameters.get("probability") != null)
			mutationProbability_ = (Double) parameters.get("probability");
	}

	@Override
	public Object execute(Object object) throws ClassNotFoundException {

		Solution s = new Solution((Solution) object);
		if(s.getSolutionType() != "Binary") {
			System.err.println("Solution type is Binary!!!");
			System.exit(-1);
		}

		double var;
		for(int i = 0, n = s.getVariables().length ; i < n; i++) {
			if(PseudoRandomGenerator.randDouble() < mutationProbability_) {
				var = s.getVariable(i);
				var = 1.0 - var;
				s.setVariable(i, var);
			}
		}
		return s;
	}

}
