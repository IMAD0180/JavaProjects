package operator.selection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

import core.Operator;
import core.Solution;
import utils.PseudoRandomGenerator;

public class RandomSelection extends Operator{

	private Comparator comparator_;

	public RandomSelection(HashMap<String, Object> parameters) {
		super(parameters);
	}

	@Override
	public Object execute(Object object) throws ClassNotFoundException {
		ArrayList<Solution> solutionSet = (ArrayList<Solution>)object;
		Solution s1, s2;
		s1 = new Solution(solutionSet.get(PseudoRandomGenerator.randInt(0, solutionSet.size())));
		s2 = new Solution(solutionSet.get(PseudoRandomGenerator.randInt(0, solutionSet.size())));

		if(PseudoRandomGenerator.randDouble() < 0.5) {
			return s1;
		} else {
			return s2;
		}
	}

}
