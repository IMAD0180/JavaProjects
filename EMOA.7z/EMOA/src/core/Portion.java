package core;

import java.util.ArrayList;

public class Portion {
	Solution solution_;
	int id_;
	double value_;
	ArrayList<Double> doubleArray_;

	public Portion(Solution s, int d) {
		solution_ = s;
		id_ = d;
	}

	public Portion(Solution s, double x) {
		solution_ = s;
		value_ = x;
	}

	public Portion(ArrayList<Double> array, int d) {
		doubleArray_ = array;
		id_ = d;
	}

	public Portion(ArrayList<Double> array, double x) {
		doubleArray_ = array;
		value_ = x;
	}

	public Portion(int d, double x) {
		id_ = d;
		value_ = x;
	}

	public int getId() {
		return id_;
	}

	public double getValue() {
		return value_;
	}
}
