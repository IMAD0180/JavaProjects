package core;

import java.util.ArrayList;

import utils.PseudoRandomGenerator;

public class Solution {

	private int numberOfVariables;

	private int numberOfObjectives;

	private String solutionType;

	double[] variables;

	double[] objectives;

	double constraintViolation;

	double attributeValue;

	double[] lowerbound = null;

	double[] upperbound = null;

	int rank;

	ArrayList<Solution> dominatesSolutionSet = new ArrayList<Solution>();

	int dominatedcounter = 0;

	double crowdingDistanceValue = 0.0;

	int individualNumber;

	public Solution(int numberOfVariables, int numberOfObjectives, String solutionType) {
		this.numberOfVariables = numberOfVariables;
		this.numberOfObjectives = numberOfObjectives;
		this.solutionType = solutionType;

		variables = new double[this.numberOfVariables];
		objectives = new double[this.numberOfObjectives];
		constraintViolation = 0.0;

		this.lowerbound = new double[this.numberOfVariables];
		this.upperbound = new double[this.numberOfVariables];
	}


	public Solution(Problem problem) {
		this.numberOfVariables = problem.getNumberOfVariables();
		this.numberOfObjectives = problem.getNumberOfObjectives();

		this.solutionType = problem.getSolutionType();
		variables = new double[this.numberOfVariables];
		objectives = new double[this.numberOfObjectives];
		constraintViolation = 0.0;

		this.lowerbound = new double[this.numberOfVariables];
		this.upperbound = new double[this.numberOfVariables];
		for(int i = 0; i < this.numberOfVariables; i++) {
			this.lowerbound[i] = problem.getLowerBound(i);
			this.upperbound[i] = problem.getUpperBound(i);
		}

		createVariables(problem);
	}


	public Solution(ArrayList<Double> x, ArrayList<Double> f, String type) {
		this.numberOfVariables = x.size();
		this.numberOfObjectives = f.size();
		this.solutionType = type;
		this.variables = new double[this.numberOfVariables];
		this.objectives = new double[this.numberOfObjectives];
		for(int i = 0; i < this.numberOfVariables; i++) {
			this.variables[i] = x.get(i);
		}
		for(int i = 0; i < this.numberOfObjectives; i++) {
			this.objectives[i] = f.get(i);
		}
		this.lowerbound = new double[this.numberOfVariables];
		this.upperbound = new double[this.numberOfVariables];
	}


	public Solution(Solution s) {
		this.numberOfVariables = s.getVariables().length;
		this.numberOfObjectives = s.getObjectives().length;

		this.solutionType = s.getSolutionType();
		variables = new double[this.numberOfVariables];
		objectives = new double[this.numberOfObjectives];
		constraintViolation = s.getConstraintViolation();

		this.lowerbound = new double[this.numberOfVariables];
		this.upperbound = new double[this.numberOfVariables];

		for(int i = 0; i < this.numberOfVariables; i++) {
			this.lowerbound[i] = s.getLowerbound(i);
			this.upperbound[i] = s.getUpperbound(i);
			this.variables[i] = s.getVariable(i);
		}

		for(int i = 0; i < this.numberOfObjectives; i++) {
			this.objectives[i] = s.getObjective(i);
		}

		this.attributeValue = s.getAttributeValue();
		this.rank = s.getRank();
		this.crowdingDistanceValue = s.getCrowdingDistance();
		this.individualNumber = s.getIndividualNumber();
		this.dominatedcounter = s.getDominatedCounter();

		if(s.getDominatesSolutionSet().size()>0) {
			for(int i = 0; i < s.getDominatesSolutionSet().size(); i++) {
				this.dominatesSolutionSet.add(s.getDominatesSolutionSet().get(i));
			}
		}

	}


	public void createVariables(Problem problem) {
		if(this.solutionType.equalsIgnoreCase("Real")) {
			for(int i = 0; i < this.numberOfVariables; i++) {
				double lb = problem.getLowerBound(i);
				double ub = problem.getUpperBound(i);
				variables[i] = PseudoRandomGenerator.randDouble(lb, ub);
				this.setLowerbound(i, lb);
				this.setUpperbound(i, ub);
			}
		} else if(this.solutionType.equalsIgnoreCase("Binary")) {
			for(int i = 0; i < this.numberOfVariables; i++) {
				if(PseudoRandomGenerator.randDouble() < 0.5) {
					variables[i] = 0.0;
				} else {
					variables[i] = 1.0;
				}
			}
		}
	}


	public void setVariables(double[] variables) {
		for(int i = 0; i < variables.length; i++) {
			this.variables[i] = variables[i];
		}
	}


	public void setVariable(int index, double variable) {
		if(index >= this.variables.length || index < 0)return;
		this.variables[index] = variable;
	}


	public void setObjectives(double[] objectives) {
		for(int i = 0; i < objectives.length; i++) {
			this.objectives[i] = objectives[i];
		}
	}


	public void setObjective(int index, double objective) {
		if(index >= this.objectives.length || index < 0)return;
		this.objectives[index] = objective;
	}


	public void setConstraintViolation(double constraintViolation) {
		this.constraintViolation = constraintViolation;
	}


	public void setAttributeValue(double attributeValue) {
		this.attributeValue = attributeValue;
	}


	public void setLowerbound(int index, double lb) {
		if(this.lowerbound == null){
			this.lowerbound = new double[this.numberOfVariables];
		}
		this.lowerbound[index] = lb;
	}


	public void setUpperbound(int index, double ub) {
		if(this.upperbound == null){
			this.upperbound = new double[this.numberOfVariables];
		}
		this.upperbound[index] = ub;
	}


	public void setRank(int rank) {
		this.rank = rank;
	}


	public void addDominatesSolutionSet(Solution q) {
		this.dominatesSolutionSet.add(q);
	}


	public void resetDominatedSolutionSet() {
		this.dominatesSolutionSet.clear();
	}


	public void setDominatedCounter(int dominatedCounter) {
		this.dominatedcounter = dominatedCounter;
	}


	public void incrementDominatedCounter() {
		this.dominatedcounter++;
	}


	public void decrementDominatedCounter() {
		this.dominatedcounter--;
	}


	public void setCrowdingDistance(double cd) {
		this.crowdingDistanceValue = cd;
	}


	public void setIndividualNumber(int id) {
		this.individualNumber = id;
	}


	public double[] getVariables() {
		return this.variables;
	}


	public int getNumberOfVariables() {
		return this.numberOfVariables;
	}


	public double getVariable(int index) {
		return this.variables[index];
	}


	public double[] getObjectives() {
		return this.objectives;
	}


	public int getNumberOfObjectives() {
		return this.numberOfObjectives;
	}


	public double getObjective(int index) {
		return this.objectives[index];
	}


	public String getSolutionType() {
		return this.solutionType;
	}

	public double getConstraintViolation() {
		return this.constraintViolation;
	}


	public double getAttributeValue() {
		return this.attributeValue;
	}


	public double getLowerbound(int index) {
		if(this.lowerbound == null){
			this.lowerbound = new double[this.numberOfVariables];
		}
		return this.lowerbound[index];
	}


	public double getUpperbound(int index) {
		if(this.upperbound == null){
			this.upperbound = new double[this.numberOfVariables];
		}
		return this.upperbound[index];
	}


	public int getRank() {
		return this.rank;
	}


	public ArrayList<Solution> getDominatesSolutionSet() {
		return this.dominatesSolutionSet;
	}


	public int getDominatedCounter() {
		return this.dominatedcounter;
	}


	public double getCrowdingDistance() {
		return this.crowdingDistanceValue;
	}


	public int getIndividualNumber() {
		return this.individualNumber;
	}
}
