package core;

import java.util.HashMap;
import java.util.Map;

public abstract class Operator {

	protected final Map<String, Object> parameters_;


	//Constructor
	public Operator(HashMap<String, Object> parameters) {
		this.parameters_ = parameters;
	}


	//execution of some operation.
	public abstract Object execute(Object object) throws ClassNotFoundException;


	//Sets a new parameter to the operator.
	public void setParameter(String name, Object object) {
		this.parameters_.put(name, object);
	}


	//Gets a parameter.
	public Object getParameter(String name) {
		return this.parameters_.get(name);
	}

}
