package problem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import core.Problem;
import core.Solution;

public class KnapsackProblem extends Problem {

	double[][] profit;

	double[][] weight;

	double[] capacity;

	double[] ratio;

	int[] deleteOrder;

	private static final double NO_CAP = 1.0e155;

	public KnapsackProblem(HashMap<String, Object> map) throws IOException, FileNotFoundException {
		super(map);

		solutionType_ = "Binary";
		problemName_ = "KnapsackProblem";

		String fileName = "";

		if(this.numberOfObjectives_ == 2) {
			fileName = "knapsack_2_500.txt";
		} else if(this.numberOfObjectives_ > 2){
			fileName = "knapsack_2_500to" + this.numberOfObjectives_ + ".txt";
		} else {
			System.out.println("Number of objectives is wrong!!!");
			System.exit(-1);
		}

		System.out.println(fileName);

		File file = new File(fileName);
		BufferedReader br = new BufferedReader(new FileReader(file));

		String str = br.readLine();
		if(this.numberOfVariables_ != Integer.parseInt(str))
			System.exit(-1);

		str = br.readLine();
		if(this.numberOfObjectives_ != Integer.parseInt(str))
			System.exit(-1);

		profit = new double[this.numberOfObjectives_][this.numberOfVariables_];
		weight = new double[this.numberOfObjectives_][this.numberOfVariables_];
		capacity = new double[this.numberOfObjectives_];
		ratio = new double[this.numberOfVariables_];
		deleteOrder = new int[this.numberOfVariables_];

		for(int j = 0; j < this.numberOfVariables_; j++) {
			ratio[j] = 0.0;
			deleteOrder[j] = j;
		}

		double q;

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			str = br.readLine();
			double d = Double.parseDouble(str);
			if(d == NO_CAP) {
				capacity[i] = Double.POSITIVE_INFINITY;
			} else {
				capacity[i] = d;
			}
			for(int j = 0; j < this.numberOfVariables_; j++) {
				str = br.readLine();
				weight[i][j] = Double.parseDouble(str);
				str = br.readLine();
				profit[i][j] = Double.parseDouble(str);

				q = profit[i][j] / weight[i][j];
				if(!Double.isInfinite(capacity[i]) && q > ratio[j])
					ratio[j] = q;

			}//for(j)
		}//for(i)

		br.close();

		deleteOrder = sortDeleteOrder(deleteOrder, ratio);
		printDeleteOrder();

	}

	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		int n = solution.getVariables().length;

		// Calculate sumOfWeight and repair vars.
		int cn = 0;
		while(excess(solution)) {
			solution.setVariable(deleteOrder[cn], 0.0);
			cn++;
		}

		for(int i = 0, m = this.numberOfObjectives_; i < m; i++) {
			double sumOfProfit = 0.0;
			for(int j = 0; j < n; j++) {
				sumOfProfit += transferToInteger(solution.getVariable(j)) * profit[i][j];
			}
			solution.setObjective(i, sumOfProfit);
		}
	}


	boolean excess(Solution solution) {
		for(int i = 0, m = this.numberOfObjectives_; i < m; i++) {
			double sumOfWeight = 0.0;
			if(Double.isInfinite(capacity[i])) return false;
			for(int j = 0, n = this.numberOfVariables_; j < n; j++) {
				sumOfWeight += transferToInteger(solution.getVariable(j)) * weight[i][j];
			}
			if(sumOfWeight > capacity[i]) return true;
		}
		return false;
	}


	int transferToInteger(double dVal) {
		int floor = (int) Math.floor(dVal);
		if(dVal-floor<0.5) {
			return (int) Math.floor(dVal);
		} else {
			return (int) Math.ceil(dVal);
		}
	}


	int[] sortDeleteOrder(final int[] index, final double[] values) {
		if(index.length != values.length)
			System.exit(-1);

		int[] id = index;
		if(id == null || id.length == 0) return id;

		double[] vals = values;

		int temp;
		double tempValue;

		for(int i = 0, n = id.length; i < n; i++) {
			for ( int j = n - 1; j > i; j-- ) {
				if(vals[j - 1] > vals[j]) {
					tempValue = vals[j - 1];
					vals[j - 1] = vals[j];
					vals[j] = tempValue;
					temp= id[j - 1];
					id[j - 1] = id[j];
					id[j] = temp;
				}
			}
		}
		return id;
	}


	void printDeleteOrder() throws IOException {
		File file = new File("deleteOrder.csv");
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

			for(int i = 0; i < deleteOrder.length; i++) {
				pw.println(deleteOrder[i]);
			}

		pw.close();
	}

////
//	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
//		KnapsackProblem mokp = new KnapsackProblem();
//		Solution s = new Solution(500, 2, "Binary");
//		for(int i = 0; i < 500; i++) {
//			s.setVariable(i, 1);
//		}
//		mokp.evaluate(s);
//		for(int i = 0; i < 2; i++) {
//			System.out.println("f" + i + ": " + s.getObjective(i));
//		}
//		System.out.println();
//
//		for(int i = 0; i < 500; i++) {
//			System.out.println(s.getVariable(i));
//		}
//
//		System.out.println();
//
//		mokp.printDeleteOrder();
//
//
////		for(int i = 0; i < 500; i++) {
////			if(i%2 == 0) {
////				s.setVariable(i, 1);
////			} else {
////				s.setVariable(i, 0);
////			}
////		}
////		mokp.evaluate(s);
////		for(int i = 0; i < 2; i++) {
////			System.out.println("f" + i + ": " + s.getObjective(i));
////		}
////		System.out.println();
////
////		for(int i = 0; i < 500; i++) {
////			if(i%2 == 0) {
////				s.setVariable(i, 0);
////			} else {
////				s.setVariable(i, 1);
////			}
////		}
////		mokp.evaluate(s);
////		for(int i = 0; i < 2; i++) {
////			System.out.println("f" + i + ": " + s.getObjective(i));
////		}
////		System.out.println();
////
////		File file = new File("repair.csv");
////		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
////
////		//pw.println(numberOfObjectives);
////		//pw.println(numberOfRuns);
////
////
////		assert(mokp.deleteOrder.length == mokp.ratio.length);
////
////		for(int i = 0; i < mokp.ratio.length; i++) {
////			pw.println(mokp.ratio[i]);
////		}
////		pw.println();
////		for(int i = 0; i < mokp.ratio.length; i++) {
////			pw.println(mokp.deleteOrder[i]);
////		}
////		pw.close();
//	}

}
