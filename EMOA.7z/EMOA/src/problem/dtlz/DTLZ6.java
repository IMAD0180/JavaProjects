package problem.dtlz;

import java.util.HashMap;

import core.Solution;

public class DTLZ6 extends DTLZ {

	public DTLZ6(HashMap<String, Object> map) {
		super(map);
	}

	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		int k = this.numberOfVariables_ - this.numberOfObjectives_ + 1;
		if(this.getInputParameter("numberOfDistanceVariables") != null)
			k = (Integer)this.getInputParameter("numberOfDistanceVariables");
		double[] f = new double[this.numberOfObjectives_];
		double g = 0.0;

		for(int i = this.numberOfVariables_ - k; i < this.numberOfVariables_; i++) {
			g += Math.pow(solution.getVariable(i), 0.1);
		}
		g += 1.0;

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			f[i] = g;
		}

		double[] biasedVars = new double[this.numberOfVariables_ - k];
		for(int i = 0; i < biasedVars.length; i++) {
			if(i == 0) {
				biasedVars[i] = solution.getVariable(i);
			} else {
				biasedVars[i] = 0.5 * (1.0 + 2 * g * solution.getVariable(i)) / (1.0 + g);
			}
		}

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			for(int j = 0; j < this.numberOfObjectives_ - (i + 1); j++)
			f[i] *= Math.cos(0.5 * Math.PI * biasedVars[i]);
			if(i != 0) {
				f[i] *= Math.sin(0.5 * Math.PI * biasedVars[this.numberOfObjectives_ - (i + 1)]);
			}
		}
		for(int i = 0; i < this.numberOfObjectives_; i++) solution.setObjective(i, f[i]);
	}

}
