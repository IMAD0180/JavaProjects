package problem.dtlz;

import java.util.HashMap;

import core.Solution;

public class ConvexDTLZ2 extends DTLZ {

	public ConvexDTLZ2(HashMap<String, Object> map) {
		super(map);
	}

	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		int k = this.numberOfVariables_ - this.numberOfObjectives_ + 1;
		if(this.getInputParameter("numberOfDistanceVariables") != null)
			k = (Integer)this.getInputParameter("numberOfDistanceVariables");
		double[] f = new double[this.numberOfObjectives_];
		double g = 0.0;

		for(int i = this.numberOfVariables_ - k; i < this.numberOfVariables_; i++) {
			g += Math.pow(solution.getVariable(i) - 0.5, 2);
		}
		g += 1.0;

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			f[i] = g;
		}


		for(int i = 0; i < this.numberOfObjectives_; i++) {
			for(int j = 0; j < this.numberOfObjectives_ - (i + 1); j++)
			f[i] *= Math.cos(0.5 * Math.PI * solution.getVariable(j));
			if(i != 0){
				f[i] *= Math.sin(0.5 * Math.PI * solution.getVariable(this.numberOfObjectives_ - (i + 1)));
			}
		}

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			double value = f[i] * f[i] * f[i] * f[i];
			if(i == this.numberOfObjectives_-1) value = f[i] * f[i];
			solution.setObjective(i, value);
		}
	}

}
