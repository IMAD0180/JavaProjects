package problem.dtlz;

import java.util.HashMap;

import core.Solution;

public class DTLZ1Normalized extends DTLZ {

	public DTLZ1Normalized(HashMap<String, Object> map) {
		super(map);
	}

	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		int k = this.numberOfVariables_ - this.numberOfObjectives_ + 1;
		if(this.getInputParameter("numberOfDistanceVariables") != null)
			k = (Integer)this.getInputParameter("numberOfDistanceVariables");
		double[] f = new double[this.numberOfObjectives_];
		double g = 0.0;
		double[] x = new double[numberOfVariables_];

		double scale = 1.0;    // scaling factor

		assert(solution.getVariables().length == this.numberOfVariables_);

		for(int i = 0; i < numberOfVariables_; i++)
			x[i] = solution.getVariable(i);

		for(int i = this.numberOfVariables_ - k; i < this.numberOfVariables_; i++) {
			g += Math.pow((x[i] - 0.5), 2.0) - Math.cos(20.0 * Math.PI * (x[i] - 0.5));
		}
		g  = 100.0 * (k + g);

		for(int i = 0; i < this.numberOfObjectives_; i++)
			f[i] = (1.0 + g) * scale;

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			for(int j = 0; j < this.numberOfObjectives_ - (i + 1); j++)
			f[i] *= x[j];
			if(i != 0){
				f[i] *= 1.0 - x[this.numberOfObjectives_ - (i + 1)];
			}
		}

		for(int i = 0; i < this.numberOfObjectives_; i++){
			//f[i] = 0.5 * (1.0 + g) - f[i];
			solution.setObjective(i, f[i]);
			//System.out.println(f[i]);
		}
	}

}
