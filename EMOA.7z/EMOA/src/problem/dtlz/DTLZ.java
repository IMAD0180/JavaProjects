package problem.dtlz;

import java.util.HashMap;

import core.Problem;
import core.Solution;

public abstract class DTLZ extends Problem {

	public DTLZ(HashMap<String, Object> map) {
		super(map);
		solutionType_ = "Real";
		problemName_ = "DTLZ";
		for(int i = 0; i < this.numberOfVariables_; i++) {
			lowerBounds_[i] = 0.0;
			upperBounds_[i] = 1.0;
		}
	}

	@Override
	public abstract void evaluate(Solution solution) throws ClassNotFoundException;

}
