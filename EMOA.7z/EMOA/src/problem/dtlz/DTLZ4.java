package problem.dtlz;

import java.util.HashMap;

import core.Solution;

public class DTLZ4 extends DTLZ {

	public DTLZ4(HashMap<String, Object> map) {
		super(map);
	}

	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		int k = this.numberOfVariables_ - this.numberOfObjectives_ + 1;
		if(this.getInputParameter("numberOfDistanceVariables") != null)
			k = (Integer)this.getInputParameter("numberOfDistanceVariables");
		double[] f = new double[this.numberOfObjectives_];
		double g = 0.0;

		for(int i = this.numberOfVariables_ - k; i < this.numberOfVariables_; i++) {
			g += Math.pow(solution.getVariable(i) - 0.5, 2);
		}

		g += 1.0;

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			f[i] = g;
		}

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			for(int j = 0; j < this.numberOfObjectives_ - (i + 1); j++)
			f[i] *= Math.cos(0.5 * Math.PI * (Math.pow(solution.getVariable(j), 100.0)));
			if(i != 0){
				f[i] *= Math.sin(0.5 * Math.PI * (Math.pow(solution.getVariable(this.numberOfObjectives_ - (i + 1)), 100.0)));
			}
		}

		for(int i = 0; i < this.numberOfObjectives_; i++)
			solution.setObjective(i, f[i]);
	}

}
