package problem.dtlz;

import java.util.HashMap;

import core.Solution;

public class DTLZ7 extends DTLZ {

	public DTLZ7(HashMap<String, Object> map) {
		super(map);
	}

	@Override
	public void evaluate(Solution solution) throws ClassNotFoundException {
		int k = this.numberOfVariables_ - this.numberOfObjectives_ + 1;
		if(this.getInputParameter("numberOfDistanceVariables") != null)
			k = (Integer)this.getInputParameter("numberOfDistanceVariables");
		double g = 0.0;

		for(int i = this.numberOfVariables_ - k; i < this.numberOfVariables_; i++) g += solution.getVariable(i);
		g *= 9.0;
		g /= (double)k;
		g += 2.0;

		for(int i = 0; i < this.numberOfObjectives_; i++) {
			if(i < this.numberOfObjectives_-1) {
				solution.setObjective(i, solution.getVariable(i));
			} else {
				double fm = g;
				double val = this.numberOfObjectives_;
				for(int j = 0; j < this.numberOfObjectives_ - 1; j++) {
					double tempVal = 1.0 + Math.sin(3 * Math.PI * solution.getVariable(j));
					val -= solution.getVariable(j) * tempVal / (1.0 + g);
				}
				fm *= val;
				solution.setObjective(i, fm);
			}
		}
	}

}
