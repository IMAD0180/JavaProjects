package runner;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import core.Algorithm;
import core.Operator;
import core.Problem;
import core.Solution;
import utils.AlgorithmSelector;
import utils.CrossoverSelector;
import utils.MutationSelector;
import utils.ProblemSelector;
import utils.PseudoRandomGenerator;
import utils.SelectionSelector;

public class ProgramRunner {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {

		Algorithm algorithm;
		Problem problem;
		Operator crossover;
		Operator mutation;
		Operator selection;

		HashMap parameters;

		String problemName = "Knapsack";
		String algorithmName = "NSGAII";
		String crossoverName = "Uniform";
		String mutationName = "BitFlip";
		String selectionName = "BinaryTournament";
		String optimize = "max";
		String fileName = "";
		double refHV = -1;
		int h1 = 12;
		int h2 = 0;
		double theta = 5.0;


		int populationSize = 100;
		int T = 20;
		int numberOfIterations = 400000;
		int numberOfGenerations = 4000;
		int numberOfRuns = 1;

		int numberOfObjectives = 10;
		int numberOfVariables = 5 + numberOfObjectives - 1;
		int numberOfConstraints = 0;


		double crossoverProbability = 1.0;
		double eta_c = 20.0;

		double mutationProbability = 1.0;
		double eta_m = 20.0;

		String sfName = "WS";
		boolean inverseVector = false;

		int numberOfPositionVariables = -1;
		int numberOfDistanceVariables = -1;


		if((args.length%2 == 0) && (args.length > 0)) {
			for(int i = 0; i < args.length; i++) {
				if(args[i].equalsIgnoreCase("-pr")) {
					problemName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-al")) {
					algorithmName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-cr")) {
					crossoverName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-mu")) {
					mutationName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-se")) {
					selectionName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-op")) {
					optimize = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-pop")) {
					populationSize = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-ite")) {
					numberOfIterations = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-gen")) {
					numberOfGenerations = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-run")) {
					numberOfRuns = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-obj")) {
					numberOfObjectives = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-var")) {
					numberOfVariables = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-con")) {
					numberOfConstraints = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-pc")) {
					crossoverProbability = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-ec")) {
					eta_c = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-pm")) {
					mutationProbability = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-h1")) {
					h1 = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-h2")) {
					h2 = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-inverse")) {
					inverseVector = Boolean.parseBoolean(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-sf")) {
					sfName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-theta")) {
					theta = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-T")) {
					T = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-em")) {
					eta_m = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-fn")) {
					fileName = args[i + 1];
				} else if(args[i].equalsIgnoreCase("-refHV")) {
					refHV = Double.parseDouble(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-pos")) {
					numberOfPositionVariables = Integer.parseInt(args[i + 1]);
				} else if(args[i].equalsIgnoreCase("-dis")) {
					numberOfDistanceVariables = Integer.parseInt(args[i + 1]);
				}
			}
		}

		PseudoRandomGenerator.setSeed(numberOfRuns+1);

		parameters = new HashMap();
		parameters.put("numberOfVariables", numberOfVariables);
		parameters.put("numberOfObjectives", numberOfObjectives);
		parameters.put("numberOfConstraints", numberOfConstraints);
		if(numberOfPositionVariables != -1) parameters.put("numberOfPositionVariables", numberOfPositionVariables);
		if(numberOfDistanceVariables != -1) parameters.put("numberOfDistanceVariables", numberOfDistanceVariables);
		problem =  (Problem)ProblemSelector.getProblem(problemName, parameters);

		if(problem == null) {
			System.out.println("problem is null! (Not matching)");
			System.exit(-1);
		}

		algorithm = (Algorithm)AlgorithmSelector.getAlgorithm(algorithmName, problem);

		algorithm.addInputParameter("populationSize", populationSize);
		algorithm.addInputParameter("sizeOfPopulation", populationSize);
		if(numberOfIterations > populationSize * numberOfGenerations)
			numberOfIterations = populationSize * numberOfGenerations;
		algorithm.addInputParameter("numberOfIterations", numberOfIterations);
		algorithm.addInputParameter("numberOfGenerations", numberOfGenerations);
		algorithm.addInputParameter("fileName", fileName);
		algorithm.addInputParameter("scalarizingFunction", sfName);
		algorithm.addInputParameter("sizeOfNeighborhood", T);
		algorithm.addInputParameter("H1", h1);
		algorithm.addInputParameter("H2", h2);
		algorithm.addInputParameter("theta", theta);
		algorithm.addInputParameter("inverse", inverseVector);
		algorithm.addInputParameter("numberOfRuns", numberOfRuns);
		if(refHV != -1) algorithm.addInputParameter("HVreference", refHV);
		if(optimize.equalsIgnoreCase("min")) {
			algorithm.addInputParameter("minimize", true);
		} else if(optimize.equalsIgnoreCase("max")){
			algorithm.addInputParameter("minimize", false);
		}


		parameters = new HashMap();
		parameters.put("probability", crossoverProbability);
		parameters.put("distributionIndex", eta_c);
		crossover = (Operator)CrossoverSelector.getCrossover(crossoverName, parameters);
		algorithm.addOperator("crossover", crossover);

		parameters = new HashMap();
		parameters.put("probability", mutationProbability / numberOfVariables);
		parameters.put("distributionIndex", eta_m);
		mutation = (Operator)MutationSelector.getMutation(mutationName, parameters);
		algorithm.addOperator("mutation", mutation);

		parameters = null;
		selection = (Operator)SelectionSelector.getSelection(selectionName, parameters);
		algorithm.addOperator("selection", selection);

		File file = new File("FUN_r" + numberOfRuns + "_m" + numberOfObjectives + ".csv");
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

		algorithm.setting();
		ArrayList<Solution> solutionSet = algorithm.execute();

		for(int i = 0; i < solutionSet.size(); i++) {
			for(int j = 0; j < solutionSet.get(i).getObjectives().length; j++) {
				//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
				pw.print(solutionSet.get(i).getObjective(j));
				if(j < solutionSet.get(i).getObjectives().length - 1)
					pw.print(" ");
			}
			pw.println();
		}

		pw.close();

		file = new File("VAR_r" + numberOfRuns + "_m" + numberOfObjectives + ".csv");
		pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

			for(int i = 0; i < solutionSet.size(); i++) {
				for(int j = 0; j < solutionSet.get(i).getVariables().length; j++) {
					//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
					pw.print(solutionSet.get(i).getVariable(j));
					if(j < solutionSet.get(i).getVariables().length - 1)
						pw.print(" ");
				}
				pw.println();
			}

		pw.close();

	}//main
}//class
