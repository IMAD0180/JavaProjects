package utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import core.Problem;
import problem.KnapsackProblem;
import problem.dtlz.ConvexDTLZ2;
import problem.dtlz.DTLZ1;
import problem.dtlz.DTLZ1Normalized;
import problem.dtlz.DTLZ2;
import problem.dtlz.DTLZ3;
import problem.dtlz.DTLZ4;
import problem.dtlz.DTLZ5;
import problem.dtlz.DTLZ6;
import problem.dtlz.DTLZ7;
import problem.dtlz.InvertedDTLZ1;
import problem.wfg.jmetal.WFG1;
import problem.wfg.jmetal.WFG2;
import problem.wfg.jmetal.WFG3;
import problem.wfg.jmetal.WFG4;
import problem.wfg.jmetal.WFG5;
import problem.wfg.jmetal.WFG6;
import problem.wfg.jmetal.WFG7;
import problem.wfg.jmetal.WFG8;
import problem.wfg.jmetal.WFG9;

public class ProblemSelector {

	public ProblemSelector() {}


	public static Object getProblem(String str, HashMap<String, Object> map) throws FileNotFoundException, IOException, ClassNotFoundException {
		Problem problem = null;

		if(str.equalsIgnoreCase("DTLZ1")) {
			problem = new DTLZ1(map);
		} else if(str.equalsIgnoreCase("DTLZ1Normalized")) {
			problem = new DTLZ1Normalized(map);
		} else if(str.equalsIgnoreCase("InvertedDTLZ1")) {
			problem = new InvertedDTLZ1(map);
		} else if(str.equalsIgnoreCase("ConvexDTLZ2")) {
			problem = new ConvexDTLZ2(map);
		} else if(str.equalsIgnoreCase("DTLZ2")) {
			problem = new DTLZ2(map);
		} else if(str.equalsIgnoreCase("DTLZ3")) {
			problem = new DTLZ3(map);
		} else if(str.equalsIgnoreCase("DTLZ4")) {
			problem = new DTLZ4(map);
		} else if(str.equalsIgnoreCase("DTLZ5")) {
			problem = new DTLZ5(map);
		} else if(str.equalsIgnoreCase("DTLZ6")) {
			problem = new DTLZ6(map);
		} else if(str.equalsIgnoreCase("DTLZ7")) {
			problem = new DTLZ7(map);
		} else if(str.equalsIgnoreCase("MOKP")) {
			problem = new KnapsackProblem(map);
		} else if(str.equalsIgnoreCase("WFG1")) {
			problem = new WFG1(map);
		} else if(str.equalsIgnoreCase("WFG2")) {
			problem = new WFG2(map);
		} else if(str.equalsIgnoreCase("WFG3")) {
			problem = new WFG3(map);
		} else if(str.equalsIgnoreCase("WFG4")) {
			problem = new WFG4(map);
		} else if(str.equalsIgnoreCase("WFG5")) {
			problem = new WFG5(map);
		} else if(str.equalsIgnoreCase("WFG6")) {
			problem = new WFG6(map);
		} else if(str.equalsIgnoreCase("WFG7")) {
			problem = new WFG7(map);
		} else if(str.equalsIgnoreCase("WFG8")) {
			problem = new WFG8(map);
		} else if(str.equalsIgnoreCase("WFG9")) {
			problem = new WFG9(map);
		}
		return problem;
	}

}
