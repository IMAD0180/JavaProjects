package utils;

import java.util.HashMap;

import core.Operator;
import operator.selection.BinaryTournamentSelection;
import operator.selection.RandomSelection;

public class SelectionSelector {

	public SelectionSelector() {

	}


	public static Object getSelection(String str, HashMap param) {
		Operator selection = null;

		if(str.equalsIgnoreCase("BinaryTournament")) {
			selection = new BinaryTournamentSelection(param);
		} else if(str.equalsIgnoreCase("Random")) {
			selection = new RandomSelection(param);
		}

		return selection;
	}

}
