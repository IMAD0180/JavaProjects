package utils;

import core.Algorithm;
import core.Problem;
import emoa.moead.MOEAD;
import emoa.nsgaii.NSGAII;
import emoa.smsemoa.SMSEMOA;
import emoa.smsemoa.SMSEMOA_IGD;
import emoa.smsemoa.SMSEMOA_Nadir;

public class AlgorithmSelector {

	public AlgorithmSelector() {

	}


	public static Object getAlgorithm(String str, Problem problem) {
		Algorithm algorithm;

		if(str.equalsIgnoreCase("NSGAII")) {
			algorithm = new NSGAII(problem);
		} else if(str.equalsIgnoreCase("MOEAD")) {
			algorithm = new MOEAD(problem);
		} else if(str.equalsIgnoreCase("SMSEMOA")) {
			algorithm = new SMSEMOA(problem);
		} else if(str.equalsIgnoreCase("SMSEMOA_Nadir")) {
			algorithm = new SMSEMOA_Nadir(problem);
		} else if(str.equalsIgnoreCase("SMSEMOA_IGD")) {
			algorithm = new SMSEMOA_IGD(problem);
		} else {
			algorithm = null;
		}

		return algorithm;
	}

}
