package utils.calculation;

import java.util.ArrayList;

import core.Solution;

public class MathCalculation {

	//calculate the center of gravity of solutionSet
	public static double[] calculateCentroid(ArrayList<Solution> solutionSet) {
		assert(solutionSet.size() > 0);
		assert(solutionSet.get(0).getObjectives().length > 0);
		double size = solutionSet.size();
		int m = solutionSet.get(0).getObjectives().length;
		double[] centroid = new double[m];

		for(int i = 0; i < m; i++) {
			centroid[i] = 0.0;
			for(int j = 0; j < solutionSet.size(); j++) {
				centroid[i] += solutionSet.get(j).getObjective(i);
			}
			centroid[i] /= size;
		}

		return centroid;
	}


	//calculate the center of gravity of lambda
	public static double[] calculateCentroid(ArrayList<ArrayList<Double>> lambda, double numberOfDimensions) {
		assert(lambda.size() > 0);
		assert(lambda.get(0).size() > 0);
		int m = (int) numberOfDimensions;
		double[] centroid = new double[m];

		for(int i = 0; i < m; i++) {
			centroid[i] = 0.0;
			for(int j = 0; j < lambda.size(); j++) {
				centroid[i] += lambda.get(j).get(i);
			}
			centroid[i] /= (double)lambda.size();
			assert(centroid[i]!=Double.NaN);
		}

		return centroid;
	}


	//calculate the center of gravity of lambda
	public static double[] calculateCentroid(double[][] lambda) {
		assert(lambda.length > 0);
		assert(lambda[0].length > 0);
		int m = lambda[0].length;
		double size = lambda.length;
		double[] centroid = new double[m];

		for(int i = 0; i < m; i++) {
			centroid[i] = 0.0;
			for(int j = 0; j < lambda.length; j++) {
				centroid[i] += lambda[j][i];
			}
			centroid[i] /= size;
		}

		return centroid;
	}


	public static double calculateEuclideanDistance(ArrayList<Double> r, double[] x) {
		assert(r.size() == x.length);
		double distance = 0.0;

		for(int i = 0; i < r.size(); i++) {
			distance += Math.pow(r.get(i) - x[i], 2);
		}
		distance = Math.sqrt(distance);

		return distance;
	}

	public static double calculateEuclideanDistance(ArrayList<Double> r1, ArrayList<Double> r2) {
		assert(r1.size() == r2.size());
		double distance = 0.0;
		for(int i = 0; i < r1.size(); i++) distance += sq(r1.get(i) - r2.get(i));
		distance = Math.sqrt(distance);
		return distance;
	}

	public static double sq(double d) {
		return d * d;
	}
}
