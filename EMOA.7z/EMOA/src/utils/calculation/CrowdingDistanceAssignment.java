package utils.calculation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import core.Solution;
import utils.comparator.ObjectiveComparator;
import utils.comparator.ParetoComparator;
import utils.ranking.NondominatedSort;

public class CrowdingDistanceAssignment {



	//Constructor
	public CrowdingDistanceAssignment() {
		//do nothing.
	}


	public void assign(ArrayList<Solution> frontSolutions, int m) {
		int size = frontSolutions.size();

		if(size == 0) {
			return;
		}

		if(size == 1) {
			frontSolutions.get(0).setCrowdingDistance(Double.MAX_VALUE);
		}

		if(size == 2) {
			frontSolutions.get(0).setCrowdingDistance(Double.MAX_VALUE);
			frontSolutions.get(1).setCrowdingDistance(Double.MAX_VALUE);
		}

		ArrayList<Solution> front = new ArrayList<Solution>();
		for(int i = 0, n = frontSolutions.size(); i < n; i++) {
			front.add(frontSolutions.get(i));
		}

		for(int i = 0, n = front.size(); i < n; i++) {
			front.get(i).setCrowdingDistance(0.0);
		}

		double dist;
		double distance;

		for(int i = 0; i < m; i++) {
			Collections.sort(front, new ObjectiveComparator(i));

			dist = Math.abs(front.get(front.size() - 1).getObjective(i) - front.get(0).getObjective(i));

			front.get(0).setCrowdingDistance(Double.MAX_VALUE);
			front.get(front.size() - 1).setCrowdingDistance(Double.MAX_VALUE);

			if(dist == 0) {
				continue;
			}

			for(int j = 1, n = front.size() - 1; j < n; j++) {
				distance = Math.abs(front.get(j + 1).getObjective(i) - front.get(j - 1).getObjective(i)) / dist;
				front.get(j).setCrowdingDistance(front.get(j).getCrowdingDistance() +  distance);
			}
		}

	}

	public static void main(String[] args) throws IOException {
		String fileName = "data.dat";
		File file = new File(fileName);
		BufferedReader br = new BufferedReader(new FileReader(file));


		String str;
		ArrayList<Solution> solutionSet = new ArrayList<Solution>();

		while((str = br.readLine()) != null) {
			String[] data = str.split("\t");
			Solution s = new Solution(5, 2, "Real");

			for(int i = 0; i < data.length; i++) {
				s.setObjective(i, Double.parseDouble(data[i]));
			}
			solutionSet.add(s);
		}

		ParetoComparator.setOptimize("max");

		NondominatedSort ranking = new NondominatedSort(solutionSet);
		for(int i = 0; i < ranking.getNumberOfSubFronts(); i++) {
			CrowdingDistanceAssignment cd = new CrowdingDistanceAssignment();
			cd.assign(ranking.getSubFront(i), 2);
		}


		for(int i = 0; i < ranking.getNumberOfSubFronts(); i++) {
			for(int j = 0; j < ranking.getSubFront(i).size(); j++) {
				System.out.println("f1: " + ranking.getSubFront(i).get(j).getObjective(0)
						+ ", f2: " + ranking.getSubFront(i).get(j).getObjective(1));
				int rank = ranking.getSubFront(i).get(j).getRank() + 1;
				System.out.println("   rank: " + rank);
				System.out.println("   cd: " + ranking.getSubFront(i).get(j).getCrowdingDistance());
				System.out.println();
			}
		}

	}

}
