package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class BinaryTournamentComparator implements Comparator<Object> {

	private Comparator dominate_ = new ParetoComparator();

	@Override
	public int compare(Object o1, Object o2) {

		int rank1, rank2;
	    rank1 = ((Solution)o1).getRank();
	    rank2 = ((Solution)o2).getRank();
	    double crowding1, crowding2;
	    crowding1 = ((Solution)o1).getCrowdingDistance();
	    crowding2 = ((Solution)o2).getCrowdingDistance();
	    if(rank1 < rank2) {
	    	return -1;
	    } else if(rank1 > rank2) {
	    	return 1;
	    } else {
	    	if (crowding1 > crowding2) {
	  	      return -1;
	  	    } else if (crowding1 < crowding2) {
	  	      return 1;
	  	    }
	    }
	    return 0;
	}
}
