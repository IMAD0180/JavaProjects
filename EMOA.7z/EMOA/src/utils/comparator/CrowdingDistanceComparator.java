package utils.comparator;

import java.util.Comparator;

import core.Solution;

public class CrowdingDistanceComparator implements Comparator<Object> {

	@Override
	public int compare(Object o1, Object o2) {
		if(o1 == null) return 1;
		if(o2 == null) return -1;
		double cd1 = ((Solution)o1).getCrowdingDistance();
		double cd2 = ((Solution)o2).getCrowdingDistance();

		if(cd1 > cd2) {
			return -1;
		} else if(cd1 < cd2) {
			return 1;
		}
		return 0;
	}

}
