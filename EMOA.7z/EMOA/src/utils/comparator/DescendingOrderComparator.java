package utils.comparator;

import java.util.Comparator;

import core.Portion;

public class DescendingOrderComparator implements Comparator<Object> {

	@Override
	public int compare(Object o1, Object o2) {
		if(o1 == null) return 1;
		if(o2 == null) return -1;
		double cd1 = ((Portion)o1).getValue();
		double cd2 = ((Portion)o2).getValue();

		if(cd1 > cd2) {
			return -1;
		} else if(cd1 < cd2) {
			return 1;
		}
		return 0;
	}

}
