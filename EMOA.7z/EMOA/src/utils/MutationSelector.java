package utils;

import java.util.HashMap;

import core.Operator;
import operator.mutation.BitFlipMutation;
import operator.mutation.PolynomialMutation;

public class MutationSelector {

	public MutationSelector() {

	}


	public static Object getMutation(String str, HashMap param) {
		Operator mutation = null;

		if(str.equalsIgnoreCase("PM")) {
			mutation = new PolynomialMutation(param);
		} else if(str.equalsIgnoreCase("BitFlip")) {
			mutation = new BitFlipMutation(param);
		}

		return mutation;
	}

}
