package utils;

import java.util.HashMap;

import core.Operator;
import operator.crossover.SBXCrossover;
import operator.crossover.SBXCrossover2;
import operator.crossover.UniformCrossover;

public class CrossoverSelector {

	public CrossoverSelector() {

	}


	public static Object getCrossover(String str, HashMap param) {
		Operator crossover = null;

		if(str.equalsIgnoreCase("SBX")) {
			crossover = new SBXCrossover(param);
		} else if(str.equalsIgnoreCase("SBX2")) {
			crossover = new SBXCrossover2(param);
		} else if(str.equalsIgnoreCase("Uniform")) {
			crossover = new UniformCrossover(param);
		}

		return crossover;
	}

}
