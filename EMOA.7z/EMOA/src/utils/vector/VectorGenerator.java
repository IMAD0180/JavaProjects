package utils.vector;

import java.util.ArrayList;

public abstract class VectorGenerator {
	protected ArrayList<ArrayList<Double>> lambda_;

	public ArrayList<ArrayList<Double>> getVectors() {
		return this.lambda_;
	}


}
