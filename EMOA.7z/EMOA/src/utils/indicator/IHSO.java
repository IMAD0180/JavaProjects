package utils.indicator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

import core.Solution;
import utils.comparator.ObjectiveComparator;

public class IHSO {
	int numberOfObjectives;
	Solution solution;
	ArrayList<Solution> solutionSet;
	double[] referencePoint;


	public class Portion{
		ArrayList<Solution> sols;
		double value;

		Portion(double val, ArrayList<Solution> pop) {
			sols = new ArrayList<>();
			for(int i = 0, size = pop.size(); i < size; i++) {
				Solution s = new Solution(pop.get(i));
				sols.add(s);
			}
			value = val;
		}

	}

	public IHSO(ArrayList<Solution> pop, double[] r, Solution sol) {
		this.solution = new Solution(sol);
		this.solutionSet = deleteDuplicatedSolution(pop);
		this.referencePoint = new double[r.length];
		referencePointDeepCopy(r, this.referencePoint);
		assert(this.referencePoint.length == this.solutionSet.get(0).getObjectives().length);
		if(this.solutionSet.size()==0) this.numberOfObjectives = 0;
		this.numberOfObjectives = this.referencePoint.length;
	}


	public double execute() {
		Solution z = solution;
		Collections.sort(this.solutionSet, new ObjectiveComparator(0, false));
		Portion portion = new Portion(1.0, solutionSet);
		ArrayList<Portion> s = new ArrayList<>();
		s.add(portion);
		for(int i = 0; i < this.numberOfObjectives-1; i++) {
			ArrayList<Portion> sTemp = new ArrayList<>();
			for(Portion port : s) {
				for(Portion por : slice(z, port.sols, i)) {
					double value = port.value * por.value;
					sTemp.add(new Portion(value, por.sols));
				}
			}
			s.clear();
			s.addAll(sTemp);
		}

		double vol = 0.0;
		for(Portion port : s) {
			double value = 0.0;
			if(port.sols.size()==0) {
				value = Math.abs(z.getObjective(this.numberOfObjectives-1)
						- this.referencePoint[this.numberOfObjectives - 1]);
			} else {
				value = Math.abs(z.getObjective(this.numberOfObjectives-1)
						- port.sols.get(0).getObjective(this.numberOfObjectives-1));
			}
			vol += port.value * value;
		}
		return vol;
	}


	ArrayList<Portion> slice(Solution z, ArrayList<Solution> pop, int k) {
		assert(pop.size()>0);
		ArrayList<Solution> pl = new ArrayList<>();
		solutionSetDeepCopy(pop, pl);
		ArrayList<Solution> ql = new ArrayList<>();
		ArrayList<Portion> s = new ArrayList<>();
		double v = z.getObjective(k);
		boolean dominated = false;

		while((pl.size() > 0) && !dominated) {
			Solution p = new Solution(pl.get(0));
			pl.remove(0);
			if(beats(v, p.getObjective(k))) {
				double value = Math.abs(v - p.getObjective(k));
				Portion portion = new Portion(value, ql);
				s.add(portion);
				v = p.getObjective(k);
			}
			ql = insert(p, k+1, ql);
			dominated = dominates(p, z, k+1);
		}
		if(!dominated) {
			double value = Math.abs(v - this.referencePoint[k]);
			Portion portion = new Portion(value, ql);
			s.add(portion);
		}
		return s;
	}


	ArrayList<Solution> insert(Solution p, int k, ArrayList<Solution> pop) {
		ArrayList<Solution> pl = new ArrayList<>();
		solutionSetDeepCopy(pop, pl);
		ArrayList<Solution> ql = new ArrayList<>();
		while((pl.size() > 0) && beats(pl.get(0).getObjective(k), p.getObjective(k))) {
			ql.add(pl.get(0));
			pl.remove(0);
		}
		ql.add(p);
		while(pl.size() > 0) {
			if(!dominates(p, pl.get(0), k)) ql.add(pl.get(0));
			pl.remove(0);
		}
		return ql;
	}


	boolean dominates(Solution p, Solution q, int k) {
		boolean d = true;
		int cn = k;
		while(d && cn < this.numberOfObjectives) {
			d = !beats(q.getObjective(cn), p.getObjective(cn));
			cn++;
		}
		return d;
	}


	boolean beats(double x, double y) {
		boolean beat = false;
		if(x > y) beat = true;
		return beat;
	}


	ArrayList<Solution> tail(ArrayList<Solution> pop) {
		ArrayList<Solution> solutionSet = new ArrayList<>();
		for(int i = 1, size = pop.size(); i < size; i++) {
			solutionSet.add(pop.get(i));
		}
		assert(solutionSet.size()+1 == pop.size());
		return solutionSet;
	}


	static ArrayList<Solution> convertToMinus(double[] r, ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		assert(r.length == solutionSet.get(0).getObjectives().length);
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			sols.add(new Solution(solutionSet.get(i)));
			for(int j = 0; j < r.length; j++) {
				double value = -1.0 * sols.get(i).getObjective(j);
				sols.get(i).setObjective(j, value);
			}
		}
		for(int i = 0; i < r.length; i++) {
			r[i] *= -1.0;
		}
		return sols;
	}


	void solutionSetDeepCopy(ArrayList<Solution> popFrom, ArrayList<Solution> popTo) {
		if(popFrom.size()==0) return;
		for(int i = 0, size = popFrom.size(); i < size; i++) {
			Solution s = new Solution(popFrom.get(i));
			popTo.add(s);
		}
	}


	void referencePointDeepCopy(double[] rFrom, double[] rTo) {
		if(rFrom.length==0) return;
		for(int i = 0, size = rFrom.length; i < size; i++) {
			rTo[i] = rFrom[i];
		}
	}


	static ArrayList<Solution> deleteNotStrongDominatingSolution(double[] r, ArrayList<Solution> solutionSet) {
		if(solutionSet.size()<=0) return solutionSet;
		ArrayList<Solution> sols = new ArrayList<>();
		for(int i = 0, size = solutionSet.size(); i < size; i++) {
			if(strongDominate(r, solutionSet.get(i)))
				sols.add(new Solution(solutionSet.get(i)));
		}
		return sols;
	}


	static boolean strongDominate(double[] r, Solution sol) {
		boolean dominate = true;
		for(int m = 0, numberOfObjectives = r.length; m < numberOfObjectives; m++) {
			if(sol.getObjective(m) <= r[m]) {
				dominate = false;
				break;
			}
		}
		return dominate;
	}


	ArrayList<Solution> deleteDuplicatedSolution(ArrayList<Solution> solutionSet) {
		assert(solutionSet.size()>0);
		Solution sol = new Solution(this.solution);
		ArrayList<Solution> sols = new ArrayList<>();
		sols.add(new Solution(solutionSet.get(0)));
		for(int i = 1, size = solutionSet.size(); i < size; i++) {
			boolean skipFlag = false;
			boolean duplicated = duplicate(sol, solutionSet.get(i));
			if(!duplicated) sols.add(new Solution(solutionSet.get(i)));
		}
		assert(sols.size() <= solutionSet.size());
		return sols;
	}


	static boolean duplicate(Solution sol1, Solution sol2) {
		boolean duplicated = true;
		assert(sol1.getObjectives().length == sol2.getObjectives().length);
		for(int m = 0, numberOfObjectives = sol1.getObjectives().length; m < numberOfObjectives; m++) {
			if(sol1.getObjective(m) != sol2.getObjective(m)) {
				duplicated = false;
				break;
			}
		}
		return duplicated;
	}


	public static void main(String args[]) {
		System.out.println("start"); /////

		String fileName = "5obj15bai.csv";
		double ri = 7.0/6.0;
		System.out.println("ri: " + ri);
		ArrayList<Solution> solutionSet = new ArrayList<>();
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			ArrayList<Double> x = new ArrayList<>();
			String type = "Real";

			while((temp = br.readLine()) != null){
				String[] array = temp.split("\t");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				Solution s = new Solution(x, refPoint, type);
				solutionSet.add(s);
			}
			br.close();
			fr.close();

			for(int i = 0; i < solutionSet.size(); i++) solutionSet.get(i).setIndividualNumber(i);

			int m = solutionSet.get(0).getObjectives().length;
			System.out.println(solutionSet.size());
			double[] r = new double[m];
			for(int i = 0; i < m; i++) {
				r[i] = ri;
			}

			boolean maximize = false;

			double[] contribution = new double[solutionSet.size()];

			if(!maximize)
				solutionSet = convertToMinus(r, solutionSet);

			for(int i = 0; i < r.length; i++)
				Collections.sort(solutionSet, new ObjectiveComparator(i, false));

			double xmax = 0.125;
			double xmin = 0.0;

			for(int i = 0, size = solutionSet.size(); i < size; i++) {
				if(!strongDominate(r, solutionSet.get(i))) {
					contribution[i] = 0.0;
					System.out.println("vol: " + 0.0);
					continue;
				}
				if((i < solutionSet.size()-1) && (duplicate(solutionSet.get(i), solutionSet.get(i+1)))) {
					contribution[i] = 0.0;
					System.out.println("vol: " + 0.0);
					continue;
				}
				ArrayList<Solution> sols = new ArrayList<>();
				Solution z = null;
				for(int j = 0; j < size; j++) {
					if(i == j) {
						z = new Solution(solutionSet.get(j));
					} else {
						sols.add(solutionSet.get(j));
					}
				}
				IHSO ihso = new IHSO(sols, r, z);
				double vol = ihso.execute();
				contribution[i] = vol;
				System.out.println("vol: " + vol);
			}

			for(int i = 0; i < contribution.length; i++) {
				if(xmax < contribution[i]) {
					xmax = contribution[i];
				} else if(xmin > contribution[i]) {
					xmin = contribution[i];
				}
			}
			if(!maximize)
				solutionSet = convertToMinus(r, solutionSet);


			double sum = xmax - xmin;
//			for(int i = 0; i < contribution.length; i++) {
//				sum += contribution[i];
//			}

			for(int i = 0; i < contribution.length; i++) {
				contribution[i] /= sum;
			}
			xmin /= sum;
			xmax /= sum;


			double ymax = 18.0;
			double ymin = 1.0;

			for(int i = 0; i < contribution.length; i++) {
				double value = (ymax - ymin) / (xmax - xmin);
				if(xmax - xmin < 1.0e-10) {
					contribution[i] = 1.1;
				} else {
					contribution[i] = value * (contribution[i] - xmin) + ymin;
				}
			}

			File file = new File("contribution.csv");
			PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
			for(int i = 0; i < solutionSet.size(); i++) {
				if(contribution[i] == 1.0) continue;

				for(int j = 0; j < solutionSet.get(i).getObjectives().length; j++) {
					//pw.println((j+1) + " " + solutionSet.get(i).getObjective(j));
					pw.print(solutionSet.get(i).getObjective(j));
					if(j < solutionSet.get(i).getObjectives().length - 1)
						pw.print("\t");
				}
				pw.print("\t" + contribution[i] + "\t0x403102");
				pw.println();
			}

		pw.close();

		} catch (IOException e) {
			System.err.println(e);
		}
	}
}
