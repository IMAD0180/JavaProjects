package utils.indicator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import core.Solution;
import utils.comparator.ObjectiveComparator;

public class HSO {
	int numberOfObjectives;
	ArrayList<Solution> solutionSet;
	double[] referencePoint;
	boolean maximize;


	public class Portion{
		ArrayList<Solution> sols;
		double value;

		Portion(double val, ArrayList<Solution> pop) {
			sols = new ArrayList<>();
			for(int i = 0, size = pop.size(); i < size; i++) {
				Solution s = new Solution(pop.get(i));
				sols.add(s);
			}
			value = val;
		}

	}

	public HSO(ArrayList<Solution> pop, double[] r, boolean flag) {
		this.solutionSet = new ArrayList<>();
		this.referencePoint = new double[r.length];
		solutionSetDeepCopy(pop, this.solutionSet);
		referencePointDeepCopy(r, this.referencePoint);
		assert(this.referencePoint.length == this.solutionSet.get(0).getObjectives().length);
		if(this.solutionSet.size()==0) this.numberOfObjectives = 0;
		this.numberOfObjectives = this.referencePoint.length;
		this.maximize = flag;
	}


	public double execute() {
		if(!this.maximize) convertToMinus();
		Collections.sort(this.solutionSet, new ObjectiveComparator(0, false));
		Portion portion = new Portion(1.0, solutionSet);
		ArrayList<Portion> s = new ArrayList<>();
		s.add(portion);
		for(int i = 0; i < this.numberOfObjectives-1; i++) {
			ArrayList<Portion> sTemp = new ArrayList<>();
			for(Portion port : s) {
				for(Portion por : slice(port.sols, i)) {
					double value = port.value * por.value;
					sTemp.add(new Portion(value, por.sols));
				}
			}
			s.clear();
			s.addAll(sTemp);
		}
		double vol = 0.0;

		for(Portion port : s) {
			double value = Math.abs(port.sols.get(0).getObjective(this.numberOfObjectives-1)
											- this.referencePoint[this.numberOfObjectives - 1]);
			vol += port.value * value;
		}
		return vol;
	}


	ArrayList<Portion> slice(ArrayList<Solution> pop, int k) {
		assert(pop.size()>0);
		Solution p = new Solution(pop.get(0));
		ArrayList<Solution> pl = new ArrayList<>();
		solutionSetDeepCopy(pop, pl);
		pl = tail(pl);
		ArrayList<Solution> ql = new ArrayList<>();
		ArrayList<Portion> s = new ArrayList<>();

		while(pl.size() > 0) {
			ql = insert(p, k+1, ql);
			Solution pTemp = new Solution(pl.get(0));
			double value = Math.abs(p.getObjective(k) - pTemp.getObjective(k));
			Portion portion = new Portion(value, ql);
			s.add(portion);
			p = new Solution(pTemp);
			pl = tail(pl);
		}
		ql = insert(p, k+1, ql);
		double value = Math.abs(p.getObjective(k) - this.referencePoint[k]);
		Portion portion = new Portion(value, ql);
		s.add(portion);
		return s;
	}


	ArrayList<Solution> insert(Solution p, int k, ArrayList<Solution> pop) {
		ArrayList<Solution> pl = new ArrayList<>();
		solutionSetDeepCopy(pop, pl);
		ArrayList<Solution> ql = new ArrayList<>();
		while((pl.size() > 0) && beats(pl.get(0).getObjective(k), p.getObjective(k))) {
			ql.add(pl.get(0));
			pl = tail(pl);
		}
		ql.add(p);
		while(pl.size() > 0) {
			if(!dominates(p, pl.get(0), k)) ql.add(pl.get(0));
			pl = tail(pl);
		}
		return ql;
	}


	boolean dominates(Solution p, Solution q, int k) {
		boolean d = true;
		int cn = k;
		while(d && cn < this.numberOfObjectives) {
			d = !beats(q.getObjective(cn), p.getObjective(cn));
			cn++;
		}
		return d;
	}


	boolean beats(double x, double y) {
		boolean beat = false;
		if(x > y) beat = true;
		return beat;
	}


	ArrayList<Solution> tail(ArrayList<Solution> pop) {
		ArrayList<Solution> solutionSet = new ArrayList<>();
		for(int i = 1, size = pop.size(); i < size; i++) {
			solutionSet.add(pop.get(i));
		}
		assert(solutionSet.size()+1 == pop.size());
		return solutionSet;
	}


	void convertToMinus() {
		for(int i = 0, size = this.solutionSet.size(); i < size; i++) {
			for(int j = 0; j < this.numberOfObjectives; j++) {
				double value = -1.0 * this.solutionSet.get(i).getObjective(j);
				this.solutionSet.get(i).setObjective(j, value);
			}
		}
		for(int i = 0; i < this.referencePoint.length; i++) {
			this.referencePoint[i] *= -1.0;
		}
	}


	void solutionSetDeepCopy(ArrayList<Solution> popFrom, ArrayList<Solution> popTo) {
		if(popFrom.size()==0) return;
		for(int i = 0, size = popFrom.size(); i < size; i++) {
			Solution s = new Solution(popFrom.get(i));
			popTo.add(s);
		}
	}


	void referencePointDeepCopy(double[] rFrom, double[] rTo) {
		if(rFrom.length==0) return;
		for(int i = 0, size = rFrom.length; i < size; i++) {
			rTo[i] = rFrom[i];
		}
	}


	public static void main(String args[]) {
		System.out.println("start"); /////

		String fileName = "5obj10bai.csv";
		double ri = 7.0/6.0;
		ArrayList<Solution> solutionSet = new ArrayList<>();
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String temp;

			ArrayList<Double> x = new ArrayList<>();
			String type = "Real";

			while((temp = br.readLine()) != null){
				String[] array = temp.split("\t");
				ArrayList<Double> refPoint = new ArrayList<>();
				for(int j = 0; j < array.length; j++){
					refPoint.add(Double.parseDouble(array[j]));
				}
				Solution s = new Solution(x, refPoint, type);
				solutionSet.add(s);
			}
			br.close();
			fr.close();

			int m = solutionSet.get(0).getObjectives().length;
			double[] r = new double[m];
			for(int i = 0; i < m; i++) {
				r[i] = ri;
			}

			boolean maximize = false;

			HSO hso = new HSO(solutionSet, r, maximize);
			double vol = hso.execute();

			System.out.println("vol: " + vol);

		} catch (IOException e) {
			System.err.println(e);
		}
	}
}
